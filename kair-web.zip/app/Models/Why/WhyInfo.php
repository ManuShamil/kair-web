<?php

namespace App\Models\Why;

use Illuminate\Database\Eloquent\Model;

class WhyInfo extends Model
{
    protected $table = "why_info";
}
