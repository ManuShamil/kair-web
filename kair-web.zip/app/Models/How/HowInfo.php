<?php

namespace App\Models\How;

use Illuminate\Database\Eloquent\Model;

class HowInfo extends Model
{
    protected $table = "how_info";
}
