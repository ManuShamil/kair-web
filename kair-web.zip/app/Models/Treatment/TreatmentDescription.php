<?php

namespace App\Models\Treatment;

use Illuminate\Database\Eloquent\Model;

class TreatmentDescription extends Model
{
    protected $table = "treatment_description";
}
