<?php

namespace App\Models\Hospital;

use Illuminate\Database\Eloquent\Model;

class HospitalSpeciality extends Model
{
    protected $table="hospital_specialities";
}
