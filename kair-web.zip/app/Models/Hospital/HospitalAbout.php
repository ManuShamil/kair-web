<?php

namespace App\Models\Hospital;

use Illuminate\Database\Eloquent\Model;

class HospitalAbout extends Model
{
    protected $table="hospital_about";
}
