<?php

namespace App\Models\Hospital;

use Illuminate\Database\Eloquent\Model;

class HospitalAddress extends Model
{
    protected $table="hospital_address";
}
