<?php

namespace App\Models\Hospital;

use Illuminate\Database\Eloquent\Model;

class HospitalImage extends Model
{
    protected $table="hospital_images";
}
