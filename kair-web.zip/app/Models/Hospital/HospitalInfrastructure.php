<?php

namespace App\Models\Hospital;

use Illuminate\Database\Eloquent\Model;

class HospitalInfrastructure extends Model
{
    protected $table="hospital_infrastructure";

}
