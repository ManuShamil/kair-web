<?php

namespace App\Models\Testimonial;

use Illuminate\Database\Eloquent\Model;

class TestimonialInfo extends Model
{
    protected $table = "testimonials_info";
}
