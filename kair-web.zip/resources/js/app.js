require('./bootstrap');
require('./nav.js');
require('./treatmentInfo.js')
require('./admin.js')
require('./callback.js')