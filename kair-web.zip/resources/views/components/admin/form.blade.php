<div class="admin-form">
    {{ $slot }}
</div>

<style>

</style>