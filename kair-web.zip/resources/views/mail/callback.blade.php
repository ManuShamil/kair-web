<p> A user has requested for a callback :  {{ $data['phone']}}</p>
