

<?php $__env->startSection('title', 'Treatment in India made easy'); ?>


<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('layouts.components.estimate'); ?> <?php if (isset($__componentOriginal9cb892bbcf1e509fb5a284afae83d5b330632cd4)): ?>
<?php $component = $__componentOriginal9cb892bbcf1e509fb5a284afae83d5b330632cd4; ?>
<?php unset($__componentOriginal9cb892bbcf1e509fb5a284afae83d5b330632cd4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('layouts.components.why'); ?> <?php if (isset($__componentOriginalb4d03122505fa20cd5816217f158292bfc327de7)): ?>
<?php $component = $__componentOriginalb4d03122505fa20cd5816217f158292bfc327de7; ?>
<?php unset($__componentOriginalb4d03122505fa20cd5816217f158292bfc327de7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('layouts.components.calltoaction'); ?> <?php if (isset($__componentOriginalca000aeced099fc2a2452b0965ac195859e5d61f)): ?>
<?php $component = $__componentOriginalca000aeced099fc2a2452b0965ac195859e5d61f; ?>
<?php unset($__componentOriginalca000aeced099fc2a2452b0965ac195859e5d61f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/home.blade.php ENDPATH**/ ?>