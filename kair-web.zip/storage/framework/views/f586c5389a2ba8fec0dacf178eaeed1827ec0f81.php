<?php
    use App\Classes\TestimonialListInfo;

    $route = Request::path();

    $testimonials = App\Models\Testimonial\Testimonial::all();

    $displayData = [];
    foreach($testimonials as $testimonial) {
        array_push($displayData, new TestimonialListInfo($testimonial));
    }

    $isAdmin = false;

    if (Session::get('isAdmin')) {
        $isAdmin = true;
    }
?>

<div class="testimonials-section">
    <div class="testimonials-container">
        <header class="container-header">
            <h2 class="section-title">What patients say <span>About KairHealth</span></h2>
            <p></p>
        </header>

        <div class="testimonial-carousel">
            <div class="stage-outer">
                <div class="stage">
                    <?php $__currentLoopData = $displayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="carousel-item">
                                <header class="carousel-item-header">
                                    <h3 class="item-title"><?php echo e($testimonial -> name); ?></h3>
                                    <p class="item-text"><?php echo e($testimonial -> quote); ?></p>
                                </header>
                                <footer class="carousel-item-footer">
                                    <img width="70px" height="70px" src="<?php echo e($testimonial -> image); ?>" class="author-photo" >
                                    <div class="author-content">
                                        <h3 class="author-name"><?php echo e($testimonial -> name); ?></h3>
                                        <a class="author-link" target="_blank"><?php echo e($testimonial -> location); ?></a>
                                    </div>
                                </footer>
                                <?php if($isAdmin): ?>
                                <div class="edit-wrapper">
                                    <div class="edit-icon">
                                        <a href="/admin/testimonial/<?php echo e($testimonial -> testimonialID); ?>/edit"></a>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div> 
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                </div>
            </div>
        </div>
    </div>
    <?php if($isAdmin): ?>
        <div class="admin-add">
            <a href="/admin/testimonial/add">+</a>
        </div>
    <?php endif; ?>
</div>

<style>
    .item {
        flex: 0 0 12.5%;

    }

    @media (max-width: 992px) {
        .item {
            flex : 0 0 25%;
        }
    }

</style><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/testimonials.blade.php ENDPATH**/ ?>