

<?php $__env->startSection('title', $pageTitle); ?>

<?php

    if ($mode == 'edit') {
        $action = "/admin/testimonial/".$testimonial->id;
    } else {
        $action = "/admin/testimonial";
    }
?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.navbar'); ?> <?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.admin.form'); ?>
        <h1> <?php echo e($pageTitle); ?> </h1>



            <?php if($mode == 'add'): ?>
            <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="name">
                    <input name="name" type="text" placeholder="Name">
                </label>
                <label for="location">
                    <input name="location" type="text" placeholder="Location">
                </label>
                <label for="testimonial">
                    <textarea name="testimonial" type="text" placeholder="Testimonial"></textarea>
                </label>
                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>
            </form>
            <?php elseif($mode == 'edit'): ?>
            <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="id" value="<?php echo e($testimonial -> id); ?>">
                <img style="height: 100px;" src="/images/<?php echo e($testimonial -> image_id); ?>">
                
                <label for="name">
                    <input value="<?php echo e($testimonial->info->first()->name??''); ?>" name="name" type="text" placeholder="Name">
                </label>
                <label for="location">
                    <input value="<?php echo e($testimonial->info->first()->location??''); ?>" name="location" type="text" placeholder="Location">
                </label>
                <label for="testimonial">
                <textarea name="testimonial" type="text" placeholder="Testimonial"><?php echo e($testimonial->info->first()->testimonial); ?></textarea>
                </label>
                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>
            </form>
            <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($testimonial -> id); ?>">
                <div class="button-wrapper">
                    <input style="background-color: #f00;"type="submit" value="Delete">
                </div>
            </form>
            <?php endif; ?>
    <?php if (isset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d)): ?>
<?php $component = $__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d; ?>
<?php unset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/pages/admin/modifytestimonial.blade.php ENDPATH**/ ?>