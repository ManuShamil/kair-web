<?php
    use App\Classes\HospitalListInfo;
    use App\Models\Hospital\Hospital;

    $route = request()->path();

    $hospitals = $hospitals ?? Hospital::all();


    $displayData = [];

    $count = 0;
    foreach($hospitals as $hospital) {
        if($route=='/' && $count>=4)
            break;
        array_push($displayData, new HospitalListInfo($hospital));
        $count++;
    }

    $isAdmin = false;

    if (Session::get('isAdmin')) {
        $isAdmin = true;
    }
?>

<div class="hospitals-section">
        <div class="hospitals-container">
            <?php if($route == '/'): ?>
            <header>
                <h2 class="section-title">Browse our <span>Hospitals</span></h2>
                <p><span>2500+</span> specialists and surgeons to choose from</p>
            </header>
            <?php endif; ?>
            <div class="row">
            <?php if($route != '/'): ?>
                <?php $__currentLoopData = $displayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column list-page">
                        <article class="list-page">
                            <img width="auto" height="auto" src="<?php echo e($hospital->image); ?>" style="background-image : url('<?php echo e($hospital->image); ?>')" class="attachment-doctor-grid-thumb size-doctor-grid-thumb wp-post-image" alt="">
                            <div class="entry-content">
                                <div style="display: flex; justify-content: space-between;">
                                    <div>
                                        <h3 class="entry-title">
                                            <a href="<?php echo e($hospital->page); ?>"><?php echo e($hospital->name); ?></a>
                                        </h3>
                                        <div class="entry-info">   
                                            <a href="<?php echo e($hospital->page); ?>"><?php echo e($hospital->location); ?></a>    
                                        </div>
                                    </div>
                                    <div>
                                        <div style="display:flex;">
                                            <?php $__currentLoopData = $hospital->accreditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accreditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="accreditaion" style="background-image : url('<?php echo e($accreditation->image); ?>')"></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="entry-info">   
                                            <a style="padding-top: 15px;display: block;text-align: right;" href="<?php echo e($hospital->page); ?>"><?php echo e($hospital->beds); ?> Beds</a>    
                                        </div>
                                    </div>
                                </div>
                                <?php if($isAdmin): ?>
                                <div class="edit-wrapper">
                                    <div class="edit-icon">
                                        <a href="/admin/hospital/<?php echo e($hospital -> id); ?>/edit"></a>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if($route != '/'): ?>
                                <hr>
                                <div class="entry-summary" style="margin-bottom: 0;">
                                    <ul style="margin-bottom: 0;">
                                        <?php $__currentLoopData = $hospital->abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($about); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                <div class="button-wrapper" style="float: right; margin-top: 0;">
                                    <a href="<?php echo e($hospital->page); ?>" >Read More...</a>
                                </div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if($route == '/'): ?>
                    <?php $__currentLoopData = $displayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column">
                        <article>
                            <figure class="overlay-effect">
                                <figure>
                                    <a href="<?php echo e($hospital->page); ?>" title="<?php echo e($hospital->name); ?>">
                                        <img width="585" height="500" src="<?php echo e($hospital->image); ?>" style="background-image : url('<?php echo e($hospital->image); ?>')" class="attachment-doctor-grid-thumb size-doctor-grid-thumb wp-post-image" alt="">
                                    </a>
                                </figure>
                                <a class="overlay" href="<?php echo e($hospital->page); ?>">
                                    <i class="top"></i> 
                                    <i class="bottom"></i>
                                </a>
                            </figure>
                            <div class="entry-content">
                                <h3 class="entry-title">
                                    <a href="<?php echo e($hospital->page); ?>"><?php echo e($hospital->name); ?></a>
                                </h3>
                                <?php if($isAdmin): ?>
                                <div class="edit-wrapper">
                                    <div class="edit-icon">
                                        <a href="/admin/hospital/<?php echo e($hospital -> id); ?>/edit"></a>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="entry-info">
                                    <a href="<?php echo e($hospital->page); ?>"><?php echo e($hospital->location); ?></a>    
                                </div>
                                <?php if($route != '/'): ?>
                                <hr>
                                <p class="entry-summary">
                                    <?php echo e($hospital->truncatedDesc); ?>

                                </p>
                                <?php endif; ?>
                                
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <?php if($route == '/'): ?>
            <div class="button-wrapper">
                <a href="/hospitals" >View all Hospitals</a>
            </div>
            <?php endif; ?>
        </div>
        <?php if($isAdmin): ?>
            <?php if($route != '/'): ?>
            <div class="admin-add">
                <a href="/admin/hospital/add">+</a>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/hospitals.blade.php ENDPATH**/ ?>