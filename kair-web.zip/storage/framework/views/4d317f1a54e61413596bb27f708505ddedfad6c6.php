

<?php $__env->startSection('title', $pageTitle); ?>


<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.admin.form'); ?>
        <h1> Add Department </h1>
        <form method="POST" action="/admin/department" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label for="department_id">
                <input name="department_id" type="text" placeholder="Enter lowercase department ID, no spaces.">
            </label>
            <label for="en_name">
                <input name="en_name" type="text" placeholder="Department Name (EN)">
            </label>
            <label for="ar_name">
                <input name="ar_name" type="text" placeholder="Department Name (AR)">
            </label>
            <label for="image">
                <input name="image" type="file" placeholder="Upload Image">
            </label>

            <div class="button-wrapper">
                <input type="submit" placeholder="Submit">
            </div>
        </form>
    <?php if (isset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d)): ?>
<?php $component = $__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d; ?>
<?php unset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/pages/admin/adddepartment.blade.php ENDPATH**/ ?>