

<?php $__env->startSection('title', $pageTitle); ?>

<?php
    use App\Models\Image;


    if ($mode == 'edit') {
        $treatment_id = $treatment -> id;
        $treatment_en = $treatment -> info -> where('language', 'en')->first -> full_name -> full_name;
        $treatment_ar = $treatment -> info -> where('language', 'ar')->first -> full_name -> full_name;
        $descriptions = $treatment->descriptions;

        $descriptionDataEN = [];
        $descriptionDataAR = [];
        for ($i=0; $i< $descriptions->where('language','en')->count(); $i++) {
            $en = $treatment->descriptions->where('priority', $i)->where('language','en')->first();
            $ar = $treatment->descriptions->where('priority', $i)->where('language','ar')->first();

            array_push($descriptionDataEN, $en);
            array_push($descriptionDataAR, $ar);
            
        }
        
        $department = $treatment -> department;

        $action = "/admin/treatment/" . $treatment_id;
    } else if ($mode =='add') {
        $action = "/admin/".$department -> id ."/treatment";
    }
?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.navbar'); ?> <?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.admin.form'); ?>
        <h1> <?php echo e($pageTitle); ?> </h1>

        <?php if($mode == 'add'): ?>
        <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <label for="department_id">
                    <input name="department_id" value="<?php echo e($department->id); ?>" type="hidden">
                </label>
                <label for="department_name">
                    <input name="department_name" value="<?php echo e($department->department_id); ?>" type="text" placeholder="<?php echo e($department->department_id); ?>" readonly>
                </label>
                <label for="treatment_id">
                    <input name="treatment_id" type="text" placeholder="Enter lowercase Treatment ID, no spaces.">
                </label>
                <label for="en_name">
                    <input name="en_name" type="text" placeholder="Treatment Name (EN)">
                </label>
                <label for="ar_name">
                    <input name="ar_name" type="text" placeholder="Treatment Name (AR)">
                </label>
                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>
        </form>
        <?php elseif($mode == 'edit'): ?>
        <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <img style="height: 100px;" src="/images/<?php echo e($treatment -> image_id); ?>">
            <label for="department_id">
                <input name="department_id" value="<?php echo e($department->id); ?>" type="hidden">
            </label>
            <label for="department_name">
                <input name="department_name" value="<?php echo e($department->department_id); ?>" type="text" placeholder="<?php echo e($department->department_id); ?>" readonly>
            </label>
            <label for="treatment_name">
                <input name="treatment_name" value="<?php echo e($treatment -> treatment_id); ?>" type="text" placeholder="Enter lowercase Treatment ID, no spaces." readonly>
            </label>
            <label for="en_name">
                <input name="en_name" value="<?php echo e($treatment_en); ?>" type="text" placeholder="Treatment Name (EN)">
            </label>
            <label for="ar_name">
                <input name="ar_name" value="<?php echo e($treatment_ar); ?>" type="text" placeholder="Treatment Name (AR)">
            </label>
            <label for="image">
                <input name="image" type="file" placeholder="Upload Image">
            </label>

            <div id="description_slot">
                <h2>Descriptions:</h2>
                <?php if(count($descriptionDataEN) <=0 ): ?>
                <div style="text-align: left;" class="description">
                    <h2>Description </h2>
                    <label for="question[]">
                        <input type="text" name="question[]" placeholder="Question in English">
                    </label>
                    <label for="answer[]">
                        <textarea type="text" name="answer[]" placeholder="Answer in English"></textarea>
                    </label>
                    <label for="question_ar[]">
                        <input type="text" name="question_ar[]" placeholder="Question in Arabic">
                    </label>
                    <label for="answer_ar[]">
                        <textarea type="text" name="answer_ar[]" placeholder="Answer in Arabic"></textarea>
                    </label>
                    <div class="admin-add add-desc" style="right: 10%;">
                        <a>+</a>
                    </div>
                </div>
                <?php endif; ?>

                <?php for($i=0; $i< count($descriptionDataEN); $i++): ?>
                <div style="text-align: left;" class="description">
                    <h2>Description </h2>
                    <label>
                        <input value="<?php echo e($descriptionDataEN[$i]->question); ?>" type="text" name="question[]" placeholder="Question in English">
                    </label>
                    <label for="answer[]">
                        <textarea type="text" name="answer[]" placeholder="Answer in English"><?php echo e($descriptionDataEN[$i]->answer); ?></textarea>
                    </label>
                    <label for="question_ar[]">
                        <input value="<?php echo e($descriptionDataAR[$i]->question); ?>" type="text" name="question_ar[]" placeholder="Question in Arabic">
                    </label>
                    <label for="answer_ar[]">
                        <textarea type="text" name="answer_ar[]" placeholder="Answer in Arabic"><?php echo e($descriptionDataAR[$i]->answer); ?></textarea>
                    </label>
                    <?php if($i>0): ?>
                    <div class="admin-add remove-desc">
                        <a>-</a>
                    </div>
                    <?php endif; ?>
                    <div class="admin-add add-desc" style="right: 10%;">
                        <a>+</a>
                    </div>
                </div>
                <?php endfor; ?>
            </div>

            <div class="button-wrapper">
                <input type="submit" placeholder="Submit">
            </div>
        </form>
        <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="department_id" value="<?php echo e($department -> id); ?>">
            <div class="button-wrapper">
                <input style="background-color: #f00;"type="submit" value="Delete">
            </div>
        </form>
        <?php endif; ?>
    <?php if (isset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d)): ?>
<?php $component = $__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d; ?>
<?php unset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/pages/admin/modifyTreatment.blade.php ENDPATH**/ ?>