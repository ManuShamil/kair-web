<p> A user has requested for a callback :  <?php echo e($data['phone']); ?></p>
<?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/mail/callback.blade.php ENDPATH**/ ?>