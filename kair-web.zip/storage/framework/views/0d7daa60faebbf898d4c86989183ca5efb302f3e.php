<p> Name : <?php echo e($data['name']); ?></p>
<p> Email : <?php echo e($data['email']); ?></p>
<p> Phone: <?php echo e($data['number']); ?></p>
<p> Message : <?php echo e($data['message']); ?></p>
<?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/mail/contact.blade.php ENDPATH**/ ?>