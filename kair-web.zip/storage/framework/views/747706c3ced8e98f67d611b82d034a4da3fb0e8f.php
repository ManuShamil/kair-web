

<?php $__env->startSection('title', $pageTitle); ?>

<?php
    use App\Models\Image;

    if ($mode == 'edit') {
        $action = "/admin/accreditation/".$accreditation->id;
    } else {
        $action = "/admin/accreditation";
    }
?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.navbar'); ?> <?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.admin.form'); ?>
        <h1> <?php echo e($pageTitle); ?> </h1>


        <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php if($mode == 'add'): ?>
                <label for="name">
                    <input name="name" type="text" placeholder="Accreditation">
                </label>
                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>

            <?php elseif($mode == 'edit'): ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="id" value="<?php echo e($accreditation -> id); ?>">
                <img style="height: 100px;" src="/images/<?php echo e($accreditation -> image_id); ?>">
                
                <label for="name">
                    <input value="<?php echo e($accreditation->title); ?>" name="name" type="text" placeholder="Accreditation">
                </label>
                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>
            <?php endif; ?>
        </form>
    <?php if (isset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d)): ?>
<?php $component = $__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d; ?>
<?php unset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/pages/admin/modifyaccreditation.blade.php ENDPATH**/ ?>