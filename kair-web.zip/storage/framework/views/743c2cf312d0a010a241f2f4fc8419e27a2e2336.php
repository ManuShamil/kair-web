<?php
    use App\Models\Department\Department;
    use App\Models\Image;
    use App\Classes\DepartmentListInfo;

    $route = request() -> path();

    $isAdmin = false;

    if (Session::get('isAdmin')) {
        $isAdmin = true;
    }

    $displayData = [];

    $count = 0;
    foreach(Department::all() as $department) {
        if ($route == '/' && $count >= 4)
            break;
        

        array_push($displayData, new DepartmentListInfo($department));

        $count++;
    }

?>

<div class="department-section">
    <div class="department-container">
        <header>
            <h2 class="section-title">Discover High Quality and Affordable Treatment in India</h2>
        </header>
        <div class="row">
            <?php $__currentLoopData = $displayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="column">
                <article>
                    <div class="thumb-wrapper">
                        <a href="<?php echo e($department -> page); ?>">
                            <img src="<?php echo e($department -> image); ?>">
                        </a>
                    </div>
                    <div class="content-wrapper">
                        <h3 class="item-title"><a href="<?php echo e($department -> page); ?>"> <?php echo e($department->departmentName); ?></a></h3>
                        <!--<div class="item-content">
                            <p>No description..</p>
                        </div>-->
                        <?php if($isAdmin): ?>
                        <div class="edit-wrapper">
                            <div class="edit-icon">
                                <a href="<?php echo e($department -> adminPage); ?>"></a>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </article>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php if(Request::path() == '/'): ?>
        <div class="button-wrapper">
            <a href="/departments"></a>
        </div>
    <?php endif; ?>

    <?php if($isAdmin): ?>
        <?php if($route != '/'): ?>
        <div class="admin-add">
            <a href="/admin/department/add">+</a>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/departments.blade.php ENDPATH**/ ?>