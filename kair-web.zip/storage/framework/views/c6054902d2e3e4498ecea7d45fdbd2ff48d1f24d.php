

<?php $__env->startSection('title', 'Why KairHealth?'); ?>


<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('layouts.components.why'); ?> <?php if (isset($__componentOriginalb4d03122505fa20cd5816217f158292bfc327de7)): ?>
<?php $component = $__componentOriginalb4d03122505fa20cd5816217f158292bfc327de7; ?>
<?php unset($__componentOriginalb4d03122505fa20cd5816217f158292bfc327de7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/why.blade.php ENDPATH**/ ?>