<?php
    use App\Classes\TreatmentListInfo;

    use App\Classes\TreatmentPageInfo;
    $displayData = new TreatmentPageInfo($treatment);

    $relatedTreatments = array();

    foreach ($treatment->department->treatments as $treatment) {
        array_push($relatedTreatments, new TreatmentListInfo($treatment));
    }
?>

<div class="treatment-info-container">
    <div class="row">
        <div class="col-1">
            <div class="treatment-info">
                <figure>
                    <a class="swipebox" title="<?php echo e($displayData -> treatmentName); ?>">
                        <img width="0" height="0" src="<?php echo e($displayData -> image); ?>" style="background-image : url('<?php echo e($displayData->image); ?>')" class="attachment-doctor-grid-thumb size-doctor-grid-thumb wp-post-image">                
                    </a>
                </figure>
                <h3 class="treatment-title"><?php echo e($displayData -> treatmentName); ?></h3>
            </div>
        </div>
        <div class="col-2">
            <div class="single-side-content">
                <h2 class="entry-title"><?php echo e($displayData -> treatmentName); ?></h2>
                <div class="entry-content">
                    <h4><?php echo e($displayData -> departmentName); ?></h4>

                    <div class="toggle-main">
                        <?php $__currentLoopData = $displayData->descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="toggle">
                            <div class="toggle-title">
                                <h3><?php echo e($description -> question); ?>

                                    <i class="fa fa-plus"></i>
                                </h3>
                            </div>
                            <div class="toggle-content" style="overflow:hidden; max-height: 0; transition: max-height 0.5s ease-out;">
                                <p><?php echo e($description -> answer); ?></p>
                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="related-treatments-container">
    <header class="home-section-header">
        <h2 class="home-section-title">Related <span>Treatments</span></h2>
        <p class="home-section-description">Treatments under <strong><?php echo e($displayData -> departmentName); ?></strong></p>                        
    </header>
    <div class="row">
        <?php $__currentLoopData = $relatedTreatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <article>
                <figure class="overlay-effect">
                    <figure>
                        <a href="<?php echo e($treatment->page); ?>" title="<?php echo e($treatment ->treatmentName); ?>">
                            <img width="585" height="500" src="<?php echo e($treatment->image); ?>" style="background-image: url('<?php echo e($treatment->image); ?>')" class="attachment-doctor-grid-thumb size-doctor-grid-thumb wp-post-image" alt="">
                        </a>
                    </figure>
                    <a class="overlay" href="<?php echo e($treatment->page); ?>">
                        <i class="top"></i> 
                        <i class="bottom"></i>
                    </a>
                </figure>
                <div class="entry-content">
                    <h3 class="entry-title">
                        <a href="<?php echo e($treatment->page); ?>"><?php echo e($treatment->treatmentName); ?></a>
                    </h3>
                    <div class="entry-info">
                        <a rel="tag"><?php echo e($treatment -> truncated_desc . '...'); ?></a>
                    </div>

                </div>
                
            </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/treatment.blade.php ENDPATH**/ ?>