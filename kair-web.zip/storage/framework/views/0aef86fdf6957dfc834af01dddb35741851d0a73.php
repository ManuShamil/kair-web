<?php
    use App\Classes\HowListInfo;

    $route = Request::path();

    $how_list = App\Models\How\How::all();


    $displayData = [];
    foreach($how_list as $how) {
        array_push($displayData, new HowListInfo($how));
    }

    $isAdmin = false;

    if (Session::get('isAdmin')) {
        $isAdmin = true;
    }
?>

<div class="why-section">
    <div class="why-container">
        <header>
            <h2 class="section-title">How it Works?</h2>
            <p><span>KairHealth</span> helps you arrange the best health care solutions in India. </p>
        </header>

        <div class="row">
            <?php $__currentLoopData = $displayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column">
                <article>
                    <div class="thumb-wrapper"><a><img src="<?php echo e($data->image); ?>" alt=""></a></div>
                    <div class="content-wrapper">
                        <?php if($isAdmin): ?>
                        <div class="edit-wrapper">
                            <div class="edit-icon">
                                <a href="/admin/how/<?php echo e($data -> howID); ?>/edit"></a>
                            </div>
                        </div>
                        <?php endif; ?>
                        <h3 class="item-title"> <?php echo e($data -> info); ?></h3>
                        <div class="item-content">
                            <p> <?php echo e($data -> description); ?></p>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($route == '/'): ?>
            <div class="button-wrapper">
                <a href="/how"></a>
            </div>
        <?php endif; ?>
    </div>
    <?php if($isAdmin): ?>
        <?php if($route != '/'): ?>
        <div class="admin-add">
            <a href="/admin/how/add">+</a>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/how.blade.php ENDPATH**/ ?>