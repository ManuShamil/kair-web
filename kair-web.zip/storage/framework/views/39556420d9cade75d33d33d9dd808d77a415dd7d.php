<?php

    $links = array();

    $count = count($paths);

    if ($count > 1)
        while ($count > 1) {
            $count -= 1;
            array_push($links, $paths[$count]);
        }


    $end = array_slice($paths, count($paths) - 2, 1);

    $end = $paths[0]

?>

<div class="banner-image">
    <div class="banner-overlay">
        <div class="bread-crumb-container">
            <h1 class="page-title">
                <?php echo e($pageTitle); ?>

            </h1>
            <nav class="bread-crumb-nav">
                <ul class="breadcrumb">
                    <li>
                        <a href="/">KairHealth</a>
                        <span class="divider"></span>
                    </li>
                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e($link -> path); ?>"> <?php echo e($link -> text); ?></a>
                        <span class="divider"></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="active">
                        <?php echo e($end -> text); ?>

                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/breadnav.blade.php ENDPATH**/ ?>