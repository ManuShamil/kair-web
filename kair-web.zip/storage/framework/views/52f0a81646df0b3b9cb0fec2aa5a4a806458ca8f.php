<div class="intro-section" style="background-image: url('/images/arfan-a-oxW5Kh_MyGQ-unsplash.jpg')">
    <div class="intro-container">
        <header>
            <h2 class="section-title">Welcome to <span>KairHealth</span></h2>
            <p></p>
        </header>
        <header style=" margin-bottom: 0;">
            <h2 class="section-title" style="font-size:2rem; font-weight: bold;">Get Price Estimate</h2>
            <p></p>
        </header>
        <div class='price-estimate'>
            <input style="flex:40%" type="text" placeholder="Search Disease...">
            <input style="flex:40%" type="text" placeholder="Choose your country...">
            <div style="flex:20%" class="button-wrapper">
                <a>Submit</a>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/layouts/components/estimate.blade.php ENDPATH**/ ?>