<?php
    use App\Classes\TreatmentListInfo;

    $treatments = $department -> treatments;

    $data = [];

    foreach ($treatments as $treatment) {
        array_push($data, new TreatmentListInfo($treatment));
    }

    $isAdmin = false;

    if (Session::get('isAdmin')) {
        $isAdmin = true;
    }
?>

<div class="treatments-list-container">
    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column">
            <article class="treatment-item">
                <div class="entry-content">

                    <div class="title-wrapper">
                        <div class="treatment-item-thumb-wrapper">
                            <figure class="overlay-effect">
                                <img width="585" height="386" src="<?php echo e($treatment->image); ?>" class="treatment-item-image">	
                                <a class="overlay"><i class="top"></i> <i class="bottom"></i></a>
                            </figure>
                        </div>
                        <h3 class="entry-title">
                            <a href="<?php echo e($treatment->page); ?>"><?php echo e($treatment->treatmentName); ?></a>
                        </h3>
                    </div>


                    <div class="entry-info">
                        <p><?php echo e($treatment->truncated_desc . '...'); ?></p>
                    </div>

                    <?php if($isAdmin): ?>
                    <div class="edit-wrapper">
                        <div class="edit-icon">
                            <a href="/admin/treatment/<?php echo e($treatment -> treatment_id); ?>/edit"></a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($isAdmin): ?>
        <div class="admin-add">
            <a href="/admin/<?php echo e($department->id); ?>/treatment/add">+</a>
        </div>
    <?php endif; ?>
    
</div>

<?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/treatments.blade.php ENDPATH**/ ?>