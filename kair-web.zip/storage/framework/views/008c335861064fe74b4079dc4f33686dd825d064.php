

<?php $__env->startSection('title', $pageTitle); ?>

<?php
    use App\Models\Image;

    class HospitalEditInfo {
        public $hospitalID;
        public $hospitalNameEN;
        public $hospitalNameAR;
        public $locationID;
        public $addressEN = "";
        public $addressAR = "";
        public $landmarkEN = "";
        public $landmarkAR = "";
        public $accreditation = [];
        public $departments = [];
        public $infrastructuresEN = [];
        public $infrastructuresAR = [];
        public $aboutEN = [];
        public $aboutAR = [];
        public $specialitiesEN = [];
        public $specialitiesAR = [];
        public $image = "/images/0";

        public function __construct($hospital) {
            $this->hospitalID = $hospital->id;
            $this->hospitalNameEN = $hospital->info->where('language','en')->first()->title;
            $this->hospitalNameAR = $hospital->info->where('language','ar')->first()->title;
            $this->locationID = $hospital->location_id;
            
            $en_address = $hospital->address->where('language','en');
            if($en_address->count() > 0){
                $this->addressEN = $en_address->first()->address;
            }        


            $ar_address = $hospital->address->where('language','ar');
            if($ar_address->count() > 0){
                $this->addressAR = $ar_address->first()->address;
            }

            $en_landmark = $hospital->address->where('language','ar');
            if($en_landmark->count() > 0){
                $this->landmarkEN = $en_landmark->first()->land_mark;
            }

            $ar_landmark = $hospital->address->where('language','ar');
            if($ar_landmark->count() > 0){
                $this->landmarkAR = $ar_landmark->first()->land_mark;
            }
            
            $this->accreditations = $hospital->accreditations;
            $this->departments = $hospital->departments;

            foreach($hospital->infrastructures->where('language','ar') as $d) {
                array_push($this->infrastructuresAR, $d);
            }

            foreach($hospital->infrastructures->where('language','en') as $d) {
                array_push($this->infrastructuresEN, $d);
            }


            foreach($hospital->about->where('language','en') as $d) {
                array_push($this->aboutEN, $d);
            }

            foreach($hospital->about->where('language','ar') as $d) {
                array_push($this->aboutAR, $d);
            }

            foreach($hospital->specialities->where('language','en') as $d) {
                array_push($this->specialitiesEN, $d);
            }

            foreach($hospital->specialities->where('language','ar') as $d) {
                array_push($this->specialitiesAR, $d);
            }

            $this->image = "/images/" . $hospital->images->first()->image_id;
        }

    }
    
    $locations = App\Models\Location::all();
    $accreditations = App\Models\Accreditation::all();
    $departments = App\Models\Department\Department::all();

    if ($mode == 'edit') {
        $action = "/admin/hospital/".$hospital->id;

        $hospitalinfo = new HospitalEditInfo($hospital);
    } else if ($mode =='add') {
        $action = "/admin/hospital/";
    }
?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.navbar'); ?> <?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.admin.form'); ?>
        <h1> <?php echo e($pageTitle); ?> </h1>

        <?php if($mode == 'add'): ?>
        <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <label for="en_name">
                    <input name="en_name" type="text" placeholder="Hospital Name (EN)">
                </label>
                <label for="ar_name">
                    <input name="ar_name" type="text" placeholder="Hospital Name (AR)">
                </label>
                <label for="beds">
                    <input name="beds" type="text" placeholder="Hospital Beds">
                </label>
                <label style="width:100%;" for="location">
                    <select style="width:100%;" name="location" value="0">
                        <option value="0">Choose a Location</option>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->id); ?>"><?php echo e($location->en_location); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <a href="/admin/location/add">Can't find location in the list? Add your own location here..</a>
                </label>
                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>
            </form>
        <?php elseif($mode == 'edit'): ?>
            <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> 
                <img style="height: 100px;" src="<?php echo e($hospitalinfo -> image); ?>">        
                <label for="en_name">
                    <input value="<?php echo e($hospitalinfo->hospitalNameEN); ?>" name="en_name" type="text" placeholder="Hospital Name (EN)">
                </label>
                <label for="ar_name">
                    <input value="<?php echo e($hospitalinfo->hospitalNameAR); ?>" name="ar_name" type="text" placeholder="Hospital Name (AR)">
                </label>
                <label style="width:100%;display:flex;" for="location">
                    <select id="location_select" style="width:100%;" name="location" onchange="changeLocationEdit()">
                        <option value="0">Choose a Location</option>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->id); ?>"<?php if($location->id == $hospitalinfo->locationID): ?> selected <?php endif; ?>><?php echo e($location->en_location); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="edit-wrapper" style="height: fit-content;">
                        <div class="edit-icon">
                            <a href="" id="location_edit" target="_blank"></a>
                        </div>
                    </div>
                    <a href="/admin/location/add">Can't find location in the list? Add your own location here..</a>
                </label>

                <div style="display: flex;">
                    <label for="en_address" style="flex: 0 0 50%;">
                        <input value="<?php echo e($hospitalinfo->addressEN); ?>" name="en_address" type="text" placeholder="Hospital Address (EN)">
                    </label>
                    <label for="ar_address" style="flex: 0 0 50%;">
                        <input value="<?php echo e($hospitalinfo->addressAR); ?>" name="ar_address" type="text" placeholder="Hospital Address (AR)">
                    </label>
                </div>

                <div style="display: flex;">
                    <label for="en_landmark" style="flex: 0 0 50%;">
                        <input value="<?php echo e($hospitalinfo->landmarkEN); ?>" name="en_landmark" type="text" placeholder="Hospital LandMark (EN)">
                    </label>
                    <label for="ar_landmark" style="flex: 0 0 50%;">
                        <input value="<?php echo e($hospitalinfo->landmarkAR); ?>" name="ar_landmark" type="text" placeholder="Hospital LandMark (AR)">
                    </label>
                </div>

                <label for="accreditations[]">
                    <div style="display: flex;">
                        <?php $__currentLoopData = $hospitalinfo->accreditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accreditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="display: flex;">
                            <input type="hidden" value="<?php echo e($accreditation->accreditation->id); ?>" name="accreditations[]" readonly>
                            <input type="text" value="<?php echo e($accreditation->accreditation->title); ?>" readonly>
                            <div class="admin-add remove-tag" style="position: inherit;">
                                <a>-</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div style="display:flex;">
                        <select id="chosen_accr" style="width: 100%;" onchange="changeAccreditationEdit()">
                            <option value="0">Choose Accreditation</option>
                            <?php $__currentLoopData = $accreditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($accr->id); ?>"><?php echo e($accr->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <div style="position: inherit;" id="addaccr" class="admin-add">
                            <a>+</a>
                        </div>
                        <div class="edit-wrapper" style="height: fit-content;">
                            <div class="edit-icon">
                                <a id="accreditation_edit" href="" target="_blank"></a>
                            </div>
                        </div>
                        <a href="/admin/accreditation/add">Can't find accreditation in the list? Add your own accreditation here..</a>
                    </div>
                </label>
                <label for="departments[]">
                    <div style="display: flex;">
                    <?php $__currentLoopData = $hospitalinfo->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="display: flex;">
                            <input type="hidden" value="<?php echo e($dept->department->id); ?>" name="departments[]" readonly>
                            <input type="text" value="<?php echo e($dept->department->info[0]->full_name); ?>" readonly>
                            <div class="admin-add remove-tag" style="position: inherit;">
                                <a>-</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div style="display:flex;">
                        <select id="chosen_dept" style="width: 100%;">
                            <option value="0">Choose Departments</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->info[0]->full_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <div style="position: inherit;" id="adddept" class="admin-add">
                            <a>+</a>
                        </div>
                    </div>
                </label>

                <h2>Infrastructure</h2>
                <div id="infras">
                    <?php for($i=0; $i< count($hospitalinfo->infrastructuresEN); $i++): ?>
                        <div style="display:flex;">
                            <label for="en_infrastructure[]" style="flex: 0 0 40%;">
                                <textarea name="en_infrastructure[]" type="text" placeholder="Hospital Infrastructure (EN)"><?php echo e($hospitalinfo->infrastructuresEN[$i]->infrastructure); ?></textarea>
                            </label>
                            <label for="ar_infrastructure[]" style="flex: 0 0 40%;">
                                <textarea name="ar_infrastructure[]" type="text" placeholder="Hospital Infrastructure (AR)"><?php echo e($hospitalinfo->infrastructuresAR[$i]->infrastructure); ?></textarea>
                            </label>
                            <div style="position: inherit;" class="admin-add addinfra">
                                <a>+</a>
                            </div>
                            <?php if($i!=0): ?>
                            <div style="position: inherit;" class="admin-add remove-infra">
                                <a>-</a>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endfor; ?>
                    <?php if(count($hospitalinfo->infrastructuresEN) <=0): ?>
                    <div style="display:flex;">
                        <label for="en_infrastructure[]" style="flex: 0 0 40%;">
                            <textarea name="en_infrastructure[]" type="text" placeholder="Hospital Infrastructure (EN)"></textarea>
                        </label>
                        <label for="ar_infrastructure[]" style="flex: 0 0 40%;">
                            <textarea name="ar_infrastructure[]" type="text" placeholder="Hospital Infrastructure (AR)"></textarea>
                        </label>
                        <div style="position: inherit;" class="admin-add addinfra">
                            <a>+</a>
                        </div>
                        <!--<div style="position: inherit;" id="adddept" class="admin-add">
                            <a>-</a>
                        </div>-->
                    </div>
                    <?php endif; ?>
                </div>

                <h2>About</h2>
                <div id="abouts">
                <?php for($i=0; $i< count($hospitalinfo->aboutEN); $i++): ?>
                        <div style="display:flex;">
                            <label for="en_about[]" style="flex: 0 0 40%;">
                                <textarea name="en_about[]" type="text" placeholder="Hospital About (EN)"><?php echo e($hospitalinfo->aboutEN[$i]->about); ?></textarea>
                            </label>
                            <label for="ar_about[]" style="flex: 0 0 40%;">
                                <textarea name="ar_about[]" type="text" placeholder="Hospital About (AR)"><?php echo e($hospitalinfo->aboutAR[$i]->about); ?></textarea>
                            </label>
                            <div style="position: inherit;" class="admin-add add-about">
                                <a>+</a>
                            </div>
                            <?php if($i!=0): ?>
                            <div style="position: inherit;" class="admin-add remove-about">
                                <a>-</a>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endfor; ?>
                    <?php if(count($hospitalinfo->aboutEN) <=0): ?>
                    <div style="display:flex;">
                        <label for="en_about[]" style="flex: 0 0 40%;">
                            <textarea name="en_about[]" type="text" placeholder="Hospital About (EN)"></textarea>
                        </label>
                        <label for="ar_about[]" style="flex: 0 0 40%;">
                            <textarea name="ar_about[]" type="text" placeholder="Hospital About (AR)"></textarea>
                        </label>
                        <div style="position: inherit;" class="admin-add add-about">
                            <a>+</a>
                        </div>
                        <!--<div style="position: inherit;" id="adddept" class="admin-add">
                            <a>-</a>
                        </div>-->
                    </div>
                    <?php endif; ?>
                </div>

                <h2>Specialities</h2>
                <div id="specialities">
                    <?php for($i=0; $i< count($hospitalinfo->specialitiesEN); $i++): ?>
                        <div style="display:flex;">
                            <label for="en_specialities[]" style="flex: 0 0 40%;">
                                <textarea name="en_specialities[]" type="text" placeholder="Hospital Speciality (EN)"><?php echo e($hospitalinfo->specialitiesEN[$i]->speciality); ?></textarea>
                            </label>
                            <label for="ar_specialities[]" style="flex: 0 0 40%;">
                                <textarea name="ar_specialities[]" type="text" placeholder="Hospital Speciality (AR)"><?php echo e($hospitalinfo->specialitiesAR[$i]->speciality); ?></textarea>
                            </label>
                            <div style="position: inherit;" class="admin-add add-speciality">
                                <a>+</a>
                            </div>
                            <?php if($i!=0): ?>
                            <div style="position: inherit;" class="admin-add remove-speciality">
                                <a>-</a>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endfor; ?>
                    <?php if(count($hospitalinfo->specialitiesEN) <=0): ?>
                    <div style="display:flex;">
                        <label for="en_specialities[]" style="flex: 0 0 40%;">
                            <textarea name="en_specialities[]" type="text" placeholder="Hospital Speciality (EN)"></textarea>
                        </label>
                        <label for="ar_specialities[]" style="flex: 0 0 40%;">
                            <textarea name="ar_specialities[]" type="text" placeholder="Hospital Speciality (AR)"></textarea>
                        </label>
                        <div style="position: inherit;" class="admin-add add-speciality">
                            <a>+</a>
                        </div>
                        <!--<div style="position: inherit;" id="adddept" class="admin-add">
                            <a>-</a>
                        </div>-->
                    </div>
                    <?php endif; ?>
                </div>

                <label for="image">
                    <input name="image" type="file" placeholder="Upload Image">
                </label>

                <div class="button-wrapper">
                    <input type="submit" placeholder="Submit">
                </div>
            </form>
            <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <div class="button-wrapper">
                    <input style="background-color: #f00;"type="submit" value="Delete">
                </div>
            </form>

            <?php endif; ?>
    <?php if (isset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d)): ?>
<?php $component = $__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d; ?>
<?php unset($__componentOriginale19147127009a0e0dcc2740743d9063c7e77f26d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <script>
        function changeLocationEdit() {
            $('#location_edit').attr('href',`/admin/location/${$('#location_select').val()}/edit`)
        }

        function changeAccreditationEdit() {
            $('#accreditation_edit').attr('href',`/admin/accreditation/${$('#chosen_accr').val()}/edit`)
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/pages/admin/modifyhospital.blade.php ENDPATH**/ ?>