

<?php $__env->startSection('title', 'Why KairHealth?'); ?>


<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.navbar'); ?> <?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.breadnav', ['paths' =>  $paths, 'pageTitle' => $pageTitle ]); ?> <?php if (isset($__componentOriginal05df7fca49c6f41347d31405a8098c0a5f951cd9)): ?>
<?php $component = $__componentOriginal05df7fca49c6f41347d31405a8098c0a5f951cd9; ?>
<?php unset($__componentOriginal05df7fca49c6f41347d31405a8098c0a5f951cd9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.why'); ?> <?php if (isset($__componentOriginalb270d14efb112b1c1803bb864278e0a5a75c7be8)): ?>
<?php $component = $__componentOriginalb270d14efb112b1c1803bb864278e0a5a75c7be8; ?>
<?php unset($__componentOriginalb270d14efb112b1c1803bb864278e0a5a75c7be8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.calltoaction'); ?> <?php if (isset($__componentOriginalb70b72349d12bdc8bac687f5e6ba25cba1e42b8f)): ?>
<?php $component = $__componentOriginalb70b72349d12bdc8bac687f5e6ba25cba1e42b8f; ?>
<?php unset($__componentOriginalb70b72349d12bdc8bac687f5e6ba25cba1e42b8f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.footer'); ?> <?php if (isset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b)): ?>
<?php $component = $__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b; ?>
<?php unset($__componentOriginal2d1e7c5cf9e06da7dcbfcd38aa098b349a88533b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/pages/why.blade.php ENDPATH**/ ?>