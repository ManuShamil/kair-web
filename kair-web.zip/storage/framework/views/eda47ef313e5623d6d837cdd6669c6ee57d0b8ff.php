<?php
    use App\Classes\HospitalInfo;
    use App\Classes\HospitalListInfo;

    $hospital = $hospital;

    $hospitalInfo = new HospitalInfo($hospital);

    $relatedHospitals = [];

    $related_hospitals = App\Models\Location::find($hospital->location_id)->hospitals;

    foreach($related_hospitals as $related) {
        array_push($relatedHospitals, new HospitalListInfo($related)); 
    }

    $isAdmin = false;

    if (Session::get('isAdmin')) {
        $isAdmin = true;
    }
?>

<div class="hospital-info-container">
    <div class="row">
        <div class="col-1">
            <div class="hospital-info">
                <figure>
                    <a class="swipebox"  title="<?php echo e($hospitalInfo-> name); ?>">
                        <img width="0" height="0"  src="<?php echo e($hospitalInfo->image); ?>" style="background-image : url('<?php echo e($hospitalInfo->image); ?>')" class="attachment-doctor-grid-thumb size-doctor-grid-thumb wp-post-image" alt="">                
                    </a>
                </figure>
                <h3 class="hospital-title"><?php echo e($hospitalInfo-> name); ?></h3>
                <?php if($isAdmin): ?>
                <div class="edit-wrapper">
                    <div class="edit-icon">
                        <a href="/admin/hospital/<?php echo e($hospital -> id); ?>/edit"></a>
                    </div>
                </div>
                <?php endif; ?>
                <div class="hospital-departments">
                    <?php $__currentLoopData = $hospitalInfo->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="department">
                        <a href="<?php echo e($department->page); ?>"><?php echo e($department->name); ?></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="hospital-specialities">
                    <p>
                        <strong>Beds</strong>
                        <span><?php echo e($hospitalInfo->beds); ?></span>
                    </p>

                    <p>
                        <strong>Accreditations</strong>
                        <?php $__currentLoopData = $hospitalInfo->accreditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accreditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="accreditaion" style="background-image : url('<?php echo e($accreditation->image); ?>')"><?php echo e($accreditation->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-2">
            <div class="single-side-content">
                <h2 class="entry-title"><?php echo e($hospitalInfo->name); ?></h2>
                <div class="entry-content">
                    <h4><?php echo e($hospitalInfo->address); ?></h4>
                    <h5><?php echo e($hospitalInfo->landmark); ?></h5>

                    <?php $__currentLoopData = $hospitalInfo->infrastructures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infrastructure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p> <?php echo e($infrastructure->infrastructure); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <h4>About <?php echo e($hospitalInfo->name); ?></h4>
                    <?php $__currentLoopData = $hospitalInfo->about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p> <?php echo e($about->about); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <h4>Achievements and Specialities </h4>
                    <ul>
                        <?php $__currentLoopData = $hospitalInfo->specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($speciality->speciality); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="related-hospitals-container">
    <header class="home-section-header">
        <h2 class="home-section-title">Related <span>Hospitals</span></h2>
        <p class="home-section-description">Looking for similar hospitals in or around <strong><?php echo e($hospitalInfo->name); ?></strong> region?</p>                        
    </header>
    <div class="row">
        <?php $__currentLoopData = $relatedHospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <article>
                <figure class="overlay-effect">
                    <figure>
                        <a href="<?php echo e($related->page); ?>" title="<?php echo e($related->name); ?>">
                            <img width="585" height="500" src="<?php echo e($related->image); ?>" style="background-image : url('<?php echo e($related->image); ?>')" class="attachment-doctor-grid-thumb size-doctor-grid-thumb wp-post-image" alt="">
                        </a>
                    </figure>
                    <a class="overlay" href="<?php echo e($related->page); ?>">
                        <i class="top"></i> 
                        <i class="bottom"></i>
                    </a>
                </figure>
                <div class="entry-content">
                    <h3 class="entry-title">
                        <a href="<?php echo e($related->page); ?>"><?php echo e($related->name); ?></a>
                    </h3>
                    <div class="entry-info">
                        <a rel="tag"><?php echo e($related->location); ?></a>
                    </div>

                </div>
                
            </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/hospital.blade.php ENDPATH**/ ?>