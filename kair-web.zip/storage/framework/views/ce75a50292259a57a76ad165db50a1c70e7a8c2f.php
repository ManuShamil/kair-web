<div class="admin-form">
    <?php echo e($slot); ?>

</div>

<style>

</style><?php /**PATH C:\Users\Admin\Documents\GitHub\kair-web\resources\views/components/admin/form.blade.php ENDPATH**/ ?>